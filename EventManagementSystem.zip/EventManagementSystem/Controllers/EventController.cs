﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventManagementSystem.Data;
using EventManagementSystem.Models;
using EventManagementSystem.Models.DTOs;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace EventManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public EventController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ Create Event (Admin Only) - Using DTO
        [HttpPost("create")]
        public async Task<IActionResult> CreateEvent([FromBody] EventDto eventDto)
        {
            var sessionToken = HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return Unauthorized("Unauthorized access.");

            var session = await _context.SessionStores.Include(s => s.User)
                            .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.ExpiresAt > System.DateTime.UtcNow);

            if (session == null || session.User.Role != "Admin")
                return Unauthorized("Only Admins can create events.");

            var eventEntity = new Event
            {
                EventName = eventDto.EventName,
                EventDate = eventDto.EventDate,
                Location = eventDto.Location,
                Description = eventDto.Description,
                OrganizerId = eventDto.OrganizerId
            };

            _context.Events.Add(eventEntity);
            await _context.SaveChangesAsync();
            return Ok(new { message = "Event created successfully." });
        }

        // ✅ Get All Events (Paginated)
        [HttpGet("all")]
        public async Task<IActionResult> GetAllEvents([FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            var events = await _context.Events
                .OrderBy(e => e.EventDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return Ok(events);
        }

        // ✅ Get Event by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEvent(int id)
        {
            var eventModel = await _context.Events.FindAsync(id);
            if (eventModel == null)
                return NotFound("Event not found.");

            return Ok(eventModel);
        }

        // ✅ Update Event (Admin Only) - Using DTO
        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] EventDto eventDto)
        {
            var sessionToken = HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return Unauthorized("Unauthorized access.");

            var session = await _context.SessionStores.Include(s => s.User)
                            .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.ExpiresAt > System.DateTime.UtcNow);

            if (session == null || session.User.Role != "Admin")
                return Unauthorized("Only Admins can update events.");

            var eventModel = await _context.Events.FindAsync(id);
            if (eventModel == null)
                return NotFound("Event not found.");

            eventModel.EventName = eventDto.EventName;
            eventModel.EventDate = eventDto.EventDate;
            eventModel.Location = eventDto.Location;
            eventModel.Description = eventDto.Description;
            eventModel.OrganizerId = eventDto.OrganizerId;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Event updated successfully." });
        }

        // ✅ Delete Event (Admin Only)
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var sessionToken = HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return Unauthorized("Unauthorized access.");

            var session = await _context.SessionStores.Include(s => s.User)
                            .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.ExpiresAt > System.DateTime.UtcNow);

            if (session == null || session.User.Role != "Admin")
                return Unauthorized("Only Admins can delete events.");

            var eventModel = await _context.Events.Include(e => e.Sessions).FirstOrDefaultAsync(e => e.EventId == id);
            if (eventModel == null)
                return NotFound("Event not found.");

            _context.Events.Remove(eventModel);
            await _context.SaveChangesAsync();
            return Ok(new { message = "Event deleted successfully." });
        }
    }
}
