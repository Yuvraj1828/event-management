﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventManagementSystem.Data;
using EventManagementSystem.DTOs;
using EventManagementSystem.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventManagementSystem.Controllers
{
    [Route("api/speakers")]
    [ApiController]
    public class SpeakerController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public SpeakerController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ GET: api/speakers (Get All Speakers)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<SpeakerDto>>> GetSpeakers()
        {
            var speakers = await _context.Speakers
                .Select(s => new SpeakerDto
                {
                    SpeakerId = s.SpeakerId,
                    SpeakerName = s.SpeakerName,
                    Email = s.Email,
                    Bio = s.Bio,
                    UserId = s.UserId,
                    SessionId = s.SessionId
                }).ToListAsync();

            return Ok(speakers);
        }

        // ✅ GET: api/speakers/{id} (Get Speaker by ID)
        [HttpGet("{id}")]
        public async Task<ActionResult<SpeakerDto>> GetSpeaker(int id)
        {
            var speaker = await _context.Speakers
                .Where(s => s.SpeakerId == id)
                .Select(s => new SpeakerDto
                {
                    SpeakerId = s.SpeakerId,
                    SpeakerName = s.SpeakerName,
                    Email = s.Email,
                    Bio = s.Bio,
                    UserId = s.UserId,
                    SessionId = s.SessionId
                }).FirstOrDefaultAsync();

            if (speaker == null)
                return NotFound(new { message = "Speaker not found" });

            return Ok(speaker);
        }

        // ✅ POST: api/speakers (Create a Speaker)
        [HttpPost]
        public async Task<ActionResult<SpeakerDto>> CreateSpeaker(SpeakerDto speakerDto)
        {
            // Check if session exists
            var session = await _context.Sessions.FindAsync(speakerDto.SessionId);
            if (session == null)
                return BadRequest(new { message = "Invalid Session ID" });

            // Check if user exists
            var user = await _context.Users.FindAsync(speakerDto.UserId);
            if (user == null)
                return BadRequest(new { message = "Invalid User ID" });

            var speaker = new Speaker
            {
                SpeakerName = speakerDto.SpeakerName,
                Email = speakerDto.Email,
                Bio = speakerDto.Bio,
                UserId = speakerDto.UserId,
                SessionId = speakerDto.SessionId
            };

            _context.Speakers.Add(speaker);
            await _context.SaveChangesAsync();

            speakerDto.SpeakerId = speaker.SpeakerId;
            return CreatedAtAction(nameof(GetSpeaker), new { id = speaker.SpeakerId }, speakerDto);
        }

        // ✅ PUT: api/speakers/{id} (Update Speaker)
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSpeaker(int id, SpeakerDto speakerDto)
        {
            if (id != speakerDto.SpeakerId)
                return BadRequest(new { message = "Speaker ID mismatch" });

            var speaker = await _context.Speakers.FindAsync(id);
            if (speaker == null)
                return NotFound(new { message = "Speaker not found" });

            speaker.SpeakerName = speakerDto.SpeakerName;
            speaker.Email = speakerDto.Email;
            speaker.Bio = speakerDto.Bio;
            speaker.UserId = speakerDto.UserId;
            speaker.SessionId = speakerDto.SessionId;

            _context.Entry(speaker).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // ✅ DELETE: api/speakers/{id} (Delete Speaker)
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSpeaker(int id)
        {
            var speaker = await _context.Speakers.FindAsync(id);
            if (speaker == null)
                return NotFound(new { message = "Speaker not found" });

            _context.Speakers.Remove(speaker);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
