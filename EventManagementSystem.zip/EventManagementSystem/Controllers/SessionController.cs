﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using EventManagementSystem.Data;
using EventManagementSystem.Models;
using EventManagementSystem.DTOs;

namespace EventManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SessionController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public SessionController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ Get All Sessions (Linked to Events & Speakers)
        [HttpGet("all")]
        public async Task<IActionResult> GetAllSessions()
        {
            var sessions = await _context.Sessions
                .Include(s => s.Event)
                .Include(s => s.Speakers)
                .ToListAsync();

            return Ok(sessions);
        }

        // ✅ Get Sessions by Event ID
        [HttpGet("event/{eventId}")]
        public async Task<IActionResult> GetSessionsByEvent(int eventId)
        {
            var sessions = await _context.Sessions
                .Where(s => s.EventId == eventId)
                .Include(s => s.Speakers)
                .ToListAsync();

            if (!sessions.Any())
                return NotFound("No sessions found for this event.");

            return Ok(sessions);
        }

        // ✅ Create a New Session (Admin Only)
        [HttpPost("create")]
        public async Task<IActionResult> CreateSession([FromBody] SessionDto sessionDto)
        {
            var sessionToken = HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return Unauthorized("Unauthorized access.");

            var session = await _context.SessionStores
                .Include(s => s.User)
                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.ExpiresAt > DateTime.UtcNow);

            if (session == null || session.User == null || session.User.Role != "Admin")
                return Unauthorized("Only Admins can create sessions.");

            // Ensure the event exists
            var eventExists = await _context.Events.AnyAsync(e => e.EventId == sessionDto.EventId);
            if (!eventExists)
                return BadRequest("Invalid Event ID.");

            var newSession = new Session
            {
                SessionName = sessionDto.SessionName,
                StartTime = sessionDto.StartTime,
                EndTime = sessionDto.EndTime,
                Description = sessionDto.Description,
                EventId = sessionDto.EventId,
                Speakers = await _context.Speakers.Where(s => sessionDto.SpeakerIds.Contains(s.SpeakerId)).ToListAsync()
            };

            _context.Sessions.Add(newSession);
            await _context.SaveChangesAsync();

            return Ok("Session created successfully.");
        }

        // ✅ Update Session (Admin Only)
        [HttpPut("update/{sessionId}")]
        public async Task<IActionResult> UpdateSession(int sessionId, [FromBody] SessionDto updatedSessionDto)
        {
            var sessionToken = HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return Unauthorized("Unauthorized access.");

            var session = await _context.SessionStores
                .Include(s => s.User)
                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.ExpiresAt > DateTime.UtcNow);

            if (session == null || session.User == null || session.User.Role != "Admin")
                return Unauthorized("Only Admins can update sessions.");

            var sessionToUpdate = await _context.Sessions.Include(s => s.Speakers).FirstOrDefaultAsync(s => s.SessionId == sessionId);
            if (sessionToUpdate == null)
                return NotFound("Session not found.");

            sessionToUpdate.SessionName = updatedSessionDto.SessionName;
            sessionToUpdate.StartTime = updatedSessionDto.StartTime;
            sessionToUpdate.EndTime = updatedSessionDto.EndTime;
            sessionToUpdate.Description = updatedSessionDto.Description;
            sessionToUpdate.Speakers = await _context.Speakers.Where(s => updatedSessionDto.SpeakerIds.Contains(s.SpeakerId)).ToListAsync();

            await _context.SaveChangesAsync();
            return Ok("Session updated successfully.");
        }

        // ✅ Delete Session (Admin Only)
        [HttpDelete("delete/{sessionId}")]
        public async Task<IActionResult> DeleteSession(int sessionId)
        {
            var sessionToken = HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return Unauthorized("Unauthorized access.");

            var session = await _context.SessionStores
                .Include(s => s.User)
                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.ExpiresAt > DateTime.UtcNow);

            if (session == null || session.User == null || session.User.Role != "Admin")
                return Unauthorized("Only Admins can delete sessions.");

            var sessionToDelete = await _context.Sessions.FindAsync(sessionId);
            if (sessionToDelete == null)
                return NotFound("Session not found.");

            _context.Sessions.Remove(sessionToDelete);
            await _context.SaveChangesAsync();

            return Ok("Session deleted successfully.");
        }
    }
}
