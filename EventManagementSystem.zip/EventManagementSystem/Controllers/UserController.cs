﻿using Microsoft.AspNetCore.Mvc;
using EventManagementSystem.Data;
using EventManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using EventManagementSystem.Models.DTOs;

namespace EventManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ User Registration (Only normal users, Admin manually inserted)
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterUserDto userDto)
        {
            if (await _context.Users.AnyAsync(u => u.Email == userDto.Email))
                return BadRequest("Email already exists.");

            if (userDto.Role != "Admin" && userDto.Role != "User")
                return BadRequest("Invalid role. Allowed values: 'Admin' or 'User'.");

            var user = new User
            {
                Username = userDto.Username,
                Email = userDto.Email,
                PasswordHash = userDto.Password,
                Bio = userDto.Bio,
                Role = userDto.Role
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok("User registered successfully.");
        }

        // ✅ User Login (Session-based Authentication)
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == request.Email && u.PasswordHash == request.Password);
            if (user == null)
                return Unauthorized("Invalid credentials.");

            // 🛠️ Ensure Old Session is Deleted First
            var existingSession = await _context.SessionStores.FirstOrDefaultAsync(s => s.UserId == user.UserId);
            if (existingSession != null)
            {
                _context.SessionStores.Remove(existingSession);
                await _context.SaveChangesAsync(); // ✅ First save before creating a new session
            }

            // ✅ Create New Session
            var sessionToken = Guid.NewGuid().ToString();
            var sessionStore = new SessionStore
            {
                UserId = user.UserId,
                SessionToken = sessionToken,
                ExpiresAt = DateTime.UtcNow.AddHours(2)
            };

            _context.SessionStores.Add(sessionStore);
            await _context.SaveChangesAsync(); // ✅ Save session

            // ✅ Set Session Token in HTTP Context
            HttpContext.Session.SetString("SessionToken", sessionToken);
            Response.Cookies.Append("SessionToken", sessionToken, new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.None
            });

            return Ok(new { message = "Login successful.", sessionToken });
        }


        // ✅ Validate Session
        [HttpGet("validate-session")]
        public async Task<IActionResult> ValidateSession()
        {
            var sessionToken = Request.Cookies["SessionToken"] ?? HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return Unauthorized("Session expired or invalid.");

            var session = await _context.SessionStores
                                .Include(s => s.User)
                                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.ExpiresAt > DateTime.UtcNow);

            if (session == null)
                return Unauthorized("Session expired.");

            var userResponse = new
            {
                session.User.UserId,
                session.User.Email,
                session.User.Role,
                session.User.Username
            };

            return Ok(new { message = "Session is valid.", user = userResponse });
        }

        // ✅ Logout (Destroy session)
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            var sessionToken = Request.Cookies["SessionToken"] ?? HttpContext.Session.GetString("SessionToken");
            if (string.IsNullOrEmpty(sessionToken))
                return BadRequest("No active session found.");

            var session = await _context.SessionStores.FirstOrDefaultAsync(s => s.SessionToken == sessionToken);
            if (session != null)
            {
                _context.SessionStores.Remove(session);
                await _context.SaveChangesAsync();
            }

            // ✅ Clear Session & Cookie
            HttpContext.Session.Remove("SessionToken");
            Response.Cookies.Delete("SessionToken");

            return Ok("Logged out successfully.");
        }
    }

    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
