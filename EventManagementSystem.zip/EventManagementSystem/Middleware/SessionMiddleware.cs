﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using EventManagementSystem.Data;
using Microsoft.EntityFrameworkCore;

namespace EventManagementSystem.Middleware
{
    public class SessionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<SessionMiddleware> _logger;

        public SessionMiddleware(RequestDelegate next, ILogger<SessionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context, ApplicationDbContext dbContext)
        {
            var sessionId = context.Session.GetString("SessionId");
            if (!string.IsNullOrEmpty(sessionId))
            {
                var session = await dbContext.SessionStores.Include(s => s.User)
                    .FirstOrDefaultAsync(s => s.SessionToken == sessionId);

                if (session != null && session.ExpiresAt > DateTime.UtcNow)
                {
                    context.Items["User"] = session.User; // Attach User to Context
                }
                else
                {
                    context.Session.Remove("SessionId"); // Expired session, remove it
                }
            }

            await _next(context);
        }
    }

    public static class SessionMiddlewareExtensions
    {
        public static IApplicationBuilder UseSessionMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<SessionMiddleware>();
        }
    }
}
