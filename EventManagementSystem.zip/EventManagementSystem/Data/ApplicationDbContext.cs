﻿using Microsoft.EntityFrameworkCore;
using EventManagementSystem.Models;
using System.Collections.Generic;

namespace EventManagementSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        // ✅ Define DbSets (Tables)
        public DbSet<User> Users { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Session> Sessions { get; set; }
        public DbSet<Speaker> Speakers { get; set; }
        public DbSet<SessionStore> SessionStores { get; set; } // ✅ For session storage

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ✅ User → Event Relationship (One-to-Many)
            modelBuilder.Entity<Event>()
                .HasOne(e => e.Organizer)
                .WithMany(u => u.Events)
                .HasForeignKey(e => e.OrganizerId)
                .OnDelete(DeleteBehavior.Restrict); // ✅ Prevent cascade delete for User → Event

            // ✅ Event → Session Relationship (One-to-Many)
            modelBuilder.Entity<Session>()
                .HasOne(s => s.Event)
                .WithMany(e => e.Sessions)
                .HasForeignKey(s => s.EventId)
                .OnDelete(DeleteBehavior.Cascade); // ✅ Event delete → Session delete

            // ✅ Session → Speaker Relationship (One-to-Many)
            modelBuilder.Entity<Speaker>()
                .HasOne(sp => sp.Session)
                .WithMany(s => s.Speakers)
                .HasForeignKey(sp => sp.SessionId)
                .OnDelete(DeleteBehavior.Cascade); // ✅ Session delete → Speaker delete

            // ✅ User → SessionStore Relationship (One-to-One)
            modelBuilder.Entity<SessionStore>()
                .HasOne(ss => ss.User)
                .WithOne(u => u.SessionStore)
                .HasForeignKey<SessionStore>(ss => ss.UserId)
                .OnDelete(DeleteBehavior.Cascade); // ✅ User delete → Session delete
        }
    }
}