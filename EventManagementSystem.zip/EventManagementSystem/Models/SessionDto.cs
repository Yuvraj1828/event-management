﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.DTOs
{
    public class SessionDto
    {
        public int? SessionId { get; set; } // PUT ke liye optional

        [Required]
        public string SessionName { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }

        public string Description { get; set; }

        [Required]
        public int EventId { get; set; }  // Foreign Key

        public int[] SpeakerIds { get; set; } // Multiple speakers ke liye array
    }
}
