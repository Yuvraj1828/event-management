﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using EventManagementSystem.Models;

namespace EventManagementSystem.Models
{
    public class Event
    {
        [Key]
        public int EventId { get; set; }

        [Required]
        public string EventName { get; set; }

        [Required]
        public DateTime EventDate { get; set; }

        public string Location { get; set; }

        public string Description { get; set; }

        // ✅ Relationship: One User → Many Events
        [Required]
        public int OrganizerId { get; set; }

        [ForeignKey("OrganizerId")]
        public User Organizer { get; set; }

        // ✅ Relationship: One Event → Many Sessions
        public ICollection<Session> Sessions { get; set; }
    }
}
