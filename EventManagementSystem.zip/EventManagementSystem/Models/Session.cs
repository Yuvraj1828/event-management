﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventManagementSystem.Models
{
    public class Session
    {
        [Key]
        public int SessionId { get; set; }

        [Required]
        public string SessionName { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }

        public string Description { get; set; }

        // ✅ Relationship: One Event → Many Sessions
        [Required]
        public int EventId { get; set; }

        [ForeignKey("EventId")]
        public Event Event { get; set; }

        // ✅ Relationship: One Session → Many Speakers
        public ICollection<Speaker> Speakers { get; set; }
    }
}
