﻿namespace EventManagementSystem.DTOs
{
    public class SpeakerDto
    {
        public int SpeakerId { get; set; }
        public string SpeakerName { get; set; }
        public string Email { get; set; }
        public string Bio { get; set; }
        public int UserId { get; set; } // ✅ User linked to Speaker
        public int SessionId { get; set; } // ✅ Speaker belongs to a Session
    }
}
