﻿namespace EventManagementSystem.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        public string Username { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required]
        public string PasswordHash { get; set; } // Hashing implement karna hai future me

        public string Bio { get; set; }

        [Required]
        public string Role { get; set; } // "Admin" or "User"

        // ✅ Relationship: One User → Many Events
        public ICollection<Event> Events { get; set; }

        // ✅ Relationship: One User → One SessionStore
        public SessionStore SessionStore { get; set; }
    }
}
