﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using EventManagementSystem.Models;

namespace EventManagementSystem.Models
{
    public class SessionStore
    {
        [Key]
        public int SessionId { get; set; }

        [Required]
        public string SessionToken { get; set; } // Unique session identifier

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime ExpiresAt { get; set; }

        // ✅ Relationship: One User → One Active Session (Each user has one active session)
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }
    }
}
