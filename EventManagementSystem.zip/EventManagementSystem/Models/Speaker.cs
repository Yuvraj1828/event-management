﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using EventManagementSystem.Models;

namespace EventManagementSystem.Models
{
    public class Speaker
    {
        [Key]
        public int SpeakerId { get; set; }

        [Required]
        public string SpeakerName { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public string Bio { get; set; }

        // ✅ Relationship: One User → Many Speakers (User Info store hoga)
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }

        // ✅ Relationship: One Session → Many Speakers
        public int SessionId { get; set; }

        [ForeignKey("SessionId")]
        public Session Session { get; set; }
    }
}
